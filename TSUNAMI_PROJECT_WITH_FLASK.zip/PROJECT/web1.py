# -*- coding: utf-8 -*-
"""
Created on Tue Aug 30 18:48:54 2022

@author: harik
"""

import numpy as np
from flask import Flask,request,render_template
import pickle

#creating flask app
flask_app = Flask(__name__)

model=pickle.load(open('model.pkl','rb'))

@flask_app.route('/')
def home():
    return render_template('home.html')

@flask_app.route('/prediction',methods=['POST'])
def predict():
    Lat= float(request.values['Latitude'])
    Lat=np.reshape(Lat,(-1,1))
    
    Lon= float(request.values['Longitude'])
    Lon=np.reshape(Lon,(-1,1))
    
    EQM= float(request.values['EQ_Magnitude'])
    EQM=np.reshape(EQM,(-1,1))
    
    EQD= float(request.values['EQ_Depth'])
    EQD=np.reshape(EQD,(-1,1))
    
    TSI= float(request.values['TS_intensity'])
    TSI=np.reshape(TSI,(-1,1))
    
    Cause = int(request.form.get('Cause'))
    Cause=np.reshape(Cause,(-1,1))

    features = [Lat,Lon,Cause,EQM,EQD,TSI]
    data_out=np.array(features).reshape(1,-1)
    prediction=model.predict(data_out)
    prediction=prediction.item()
    
    if prediction==0:
        name='Definite Tsunami'
    elif prediction==3:
        name='Questionable Tsunami'
    elif prediction==2:
        name='Probable Tsunami'
    elif prediction==4:
        name='Very Doubtful Tsunami'
    else:
        name='Event that only caused a seiche or disturbance in an inland river'
        
        
    return render_template('home.html',prediction_text="Tsunami Event Validity is :  {}".format(name))

if __name__=='__main__':
    flask_app.run(port=8000)


